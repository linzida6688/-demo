//
//  AppDelegate.h
//  直播demo
//
//  Created by Lindashuai on 2020/2/6.
//  Copyright © 2020 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

