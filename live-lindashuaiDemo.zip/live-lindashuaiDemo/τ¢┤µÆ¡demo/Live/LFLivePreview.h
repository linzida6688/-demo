//
//  LFLivePreview.h
//  直播demo
//
//  Created by Lindashuai on 2020/2/6.
//  Copyright © 2020 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LFLivePreviewDelegate <NSObject>
@optional
- (void)closeLiveClick;

@end
@interface LFLivePreview : UIView <LFLivePreviewDelegate>
@property(nonatomic, weak) id<LFLivePreviewDelegate> delegate;

- (void)startLive;//开始直播

- (void)stopLive;//停止直播

@end
