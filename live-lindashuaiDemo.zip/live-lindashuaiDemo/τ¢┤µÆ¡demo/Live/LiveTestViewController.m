//
//  LiveTestViewController.m
//  直播demo
//
//  Created by Lindashuai on 2020/2/6.
//  Copyright © 2020 Lindashuai. All rights reserved.
//

#import "LiveTestViewController.h"
#import "LFLivePreview.h"

@interface LiveTestViewController () <LFLivePreviewDelegate>

@property(nonatomic, strong) LFLivePreview *liveView;

@end

@implementation LiveTestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //Privacy - Camera Usage Description        打开相机-live
    //Privacy - Microphone Usage Description    允许打开-live
    [self.view addSubview:self.liveView];
    [self.liveView startLive];
}

- (LFLivePreview *)liveView {
    if(_liveView == nil) {
        _liveView = [[LFLivePreview alloc] initWithFrame:self.view.bounds];
        _liveView.delegate = self;
    }
    return _liveView;
}

#pragma mark - LFLivePreviewDelegate

- (void)closeLiveClick {
    __weak typeof(self) weakSelf = self;
    [self dismissViewControllerAnimated:YES completion:^{
        [weakSelf.liveView stopLive];
    }];
}

@end
