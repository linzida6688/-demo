//
//  ViewController.m
//  直播demo
//
//  Created by Lindashuai on 2020/2/6.
//  Copyright © 2020 Lindashuai. All rights reserved.
//

#import "ViewController.h"
#import "LiveTestViewController.h"//直播页面
#import "ShowTestViewController.h"//看直播

@interface ViewController ()

@property(nonatomic, strong) UIButton *wantPlayer;
@property(nonatomic, strong) UIButton *lookPlayer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.wantPlayer];
    [self.view addSubview:self.lookPlayer];
}

- (void)wantPlayerBtn {//我要直播
    LiveTestViewController *liveTestViewController = [[LiveTestViewController alloc]init];
    [self presentViewController:liveTestViewController animated:YES completion:nil];
}

- (void)lookPlayerBtn {//观看直播
    ShowTestViewController *showTestViewController = [[ShowTestViewController alloc]init];
    [self presentViewController:showTestViewController animated:YES completion:nil];
}

- (UIButton *)wantPlayer {
    if(_wantPlayer == nil) {
        _wantPlayer = [[UIButton alloc]initWithFrame:CGRectMake(0, 200, self.view.frame.size.width, 50)];
        [_wantPlayer setTitle:@"我要直播" forState:UIControlStateNormal];
        [_wantPlayer setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _wantPlayer.titleLabel.font = [UIFont systemFontOfSize:14];
        [_wantPlayer addTarget:self action:@selector(wantPlayerBtn) forControlEvents:UIControlEventTouchUpInside];
    }
    return _wantPlayer;
}

- (UIButton *)lookPlayer {
    if(_lookPlayer == nil) {
        _lookPlayer = [[UIButton alloc]initWithFrame:CGRectMake(0, 300, self.view.frame.size.width, 50)];
        [_lookPlayer setTitle:@"观看直播" forState:UIControlStateNormal];
        [_lookPlayer setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _lookPlayer.titleLabel.font = [UIFont systemFontOfSize:14];
        [_lookPlayer addTarget:self action:@selector(lookPlayerBtn) forControlEvents:UIControlEventTouchUpInside];
    }
    return _lookPlayer;
}

@end
